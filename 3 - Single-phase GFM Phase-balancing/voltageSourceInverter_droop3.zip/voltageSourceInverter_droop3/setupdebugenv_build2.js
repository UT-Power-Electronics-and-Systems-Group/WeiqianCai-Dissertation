//AddWatchWindowVars Build 2
expRemoveAll()
//Inverter Variables
expAdd ("clearInvTrip", getNatural())
expAdd ("rlyConnect",getNatural())
expAdd ("invIiRef",getNatural())
expAdd ("invIiRefInst",getNatural())
expAdd ("invIiInst",getNatural())
expAdd ("closeILoopInv",getNatural())
expAdd ("boardStatus",getNatural())
expAdd ("BuildInfo",getNatural())
expAdd ("EPwm1Regs.TZFLG",getNatural())
expAdd ("EPwm2Regs.TZFLG",getNatural())
expAdd ("guiVbus",getNatural())
expAdd ("guiPrms",getNatural())
expAdd ("guiVrms",getNatural())
expAdd ("guiIrms",getNatural())
expAdd ("guiVo",getNatural())
expAdd ("guiIo",getNatural())
expAdd ("guiIi",getNatural())
expAdd ("guiFreqAvg",getNatural())
expAdd ("guiVema",getNatural())


