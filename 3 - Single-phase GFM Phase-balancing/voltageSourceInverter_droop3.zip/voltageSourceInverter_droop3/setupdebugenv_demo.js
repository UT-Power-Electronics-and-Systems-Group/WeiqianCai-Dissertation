//AddWatchWindowVars
expRemoveAll()
expAdd ("guiInvStart",getNatural())
expAdd ("guiInvStop",getNatural())
expAdd ("boardState",getNatural())
expAdd ("boardStatus",getNatural())
expAdd ("BuildInfo",getNatural())
expAdd ("guiVbus",getNatural())
expAdd ("guiPrms",getNatural())
expAdd ("guiVrms",getNatural())
expAdd ("guiIrms",getNatural())
expAdd ("guiVo",getNatural())
expAdd ("guiIo",getNatural())
expAdd ("guiIi",getNatural())
expAdd ("guiFreqAvg",getNatural())
expAdd ("guiVema",getNatural())
expAdd ("guiPowerFactor",getNatural())




