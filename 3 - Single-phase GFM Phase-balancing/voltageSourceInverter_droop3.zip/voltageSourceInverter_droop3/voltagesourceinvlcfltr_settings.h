#ifndef _PROJSETTINGS_H
#define _PROJSETTINGS_H

#ifdef __cplusplus

extern "C" {
#endif

//*****************************************************************************
//defines
//*****************************************************************************

/* Device Related Defines */
#define CPU_SYS_CLOCK (200*1000000)
#define PWMSYSCLOCK_FREQ (100*1000000)
#define ECAPSYSCLOCK_FREQ	(200*1000000)

/* Project Options*/
//==================================================================================
// Incremental Build options for System check-out
//==================================================================================
// BUILD 1 	 Open Loop Check the Inverter
// BUILD 2   Closed Current Loop Inverter forced sine angle
// BUILD 3   Voltage loop with inner current loop
#define INCR_BUILD  3
// Check system under DC condition (cleanest SFRA curves) 0 is FALSE, 1 is TRUE
#define DC_CHECK  0
// Select sensing option, 1 for ADC, 2 for SDFM
#define ADC_BASED_SENSING   1
#define SDFM_BASED_SENSING  2
#define SENSING_OPTION		2
#define AC_FREQ        		60

/* Power Stage Related Values*/
#define INV_PWM_SWITCHING_FREQUENCY ((float)20*1000)

#define INV_DEADBAND_US 0.2
#define INV_PWM_PERIOD (PWMSYSCLOCK_FREQ)/(INV_PWM_SWITCHING_FREQUENCY)
#define INV_DEADBAND_PWM_COUNT (int)((float)INV_DEADBAND_US*(float)PWMSYSCLOCK_FREQ*(float)0.000001)

#define VAC_MAX_SENSE 620.152
#define VDCBUS_MAX_SENSE 620.152
#define I_MAX_SENSE 15.6
#define I_TRIP_LIMIT 14
#define VAC_TYPICAL 220

/* Control Loop Design */

#define ISR_CONTROL_FREQUENCY (INV_PWM_SWITCHING_FREQUENCY)/(CNTRL_ISR_FREQ_RATIO)
#define	CNTRL_ISR_FREQ_RATIO	1
#define VOLTAGE_LOOP_RUN_RATIO	1

//SFRA Options
//1 FRA for the Voltage Loop
//2 FRA for the Current Loop
#define SFRA_TYPE			1
#define SFRA_ISR_FREQ 		ISR_CONTROL_FREQUENCY

#define PI_VALUE 3.141592653589
#define KPV_1H        		2 // 1//0.75
#define KIV_1H        		2000 * 2
#define WRCV_1H        		0.00628
#define KIV_3H        		0//1000
#define WRCV_3H        		0.031415
#define KIV_5H        		0//1000
#define WRCV_5H        		0.031415
#define KIV_7H        		0//500
#define WRCV_7H        		0.031415

#define CNTL_INV_I_3P3Z_A1 1.0000000000
#define CNTL_INV_I_3P3Z_A2 0.0000000000
#define CNTL_INV_I_3P3Z_A3 0.0000000000
#define CNTL_INV_I_3P3Z_B0 0.5467500000
#define CNTL_INV_I_3P3Z_B1 -0.4252500000
#define CNTL_INV_I_3P3Z_B2 0.0000000000
#define CNTL_INV_I_3P3Z_B3 0.0000000000
#define CNTL_INV_I_3P3Z_IMIN -1.0
#define CNTL_INV_I_3P3Z_MAX 1.0
#define CNTL_INV_I_3P3Z_MIN -1.0

#define PI_KP 0.5093949150 * 2
#define PI_KI 0.0812101701 * 2

#define CNTL_LEADLAG_V_2P2Z_A1 -0.8789881828
#define CNTL_LEADLAG_V_2P2Z_A2 0.0000000000
#define CNTL_LEADLAG_V_2P2Z_B0 4.3590034523
#define CNTL_LEADLAG_V_2P2Z_B1 -4.2308212342
#define CNTL_LEADLAG_V_2P2Z_B2 0.0000000000
#define CNTL_LEADLAG_V_2P2Z_IMIN -1.0
#define CNTL_LEADLAG_V_2P2Z_MAX 1.0
#define CNTL_LEADLAG_V_2P2Z_MIN -1.0

/* SDFM Sensing Parameters*/

#define SDCLK_FREQ		(float)(20*1000000)
#define SD_CLK_COUNT ECAPSYSCLOCK_FREQ/SDCLK_FREQ
#define PWM_CLK_IN_SDFM_OSR (int)(((float)PWMSYSCLOCK_FREQ/(float)SDCLK_FREQ)*(float)SDFM_OSR)
#define SDFM_FILTER_TYPE	3
#define SDFM_OSR			128

//=============================================================================
// User code settings file
//=============================================================================
#include "voltagesourceinvlcfltr_user_settings.h"

#ifdef __cplusplus
}
#endif                                  /* extern "C" */

#endif //_PROJSETTINGS_H
